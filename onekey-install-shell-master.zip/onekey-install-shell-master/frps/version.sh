#!/bin/bash
export FRPS_VER=0.47.0
export FRPS_INIT="https://raw.githubusercontent.com/clangcn/onekey-install-shell/master/frps/frps.init"
export aliyun_download_url="https://code.aliyun.com/clangcn/frp/raw/master"
export github_download_url="https://github.com/fatedier/frp/releases/download"
